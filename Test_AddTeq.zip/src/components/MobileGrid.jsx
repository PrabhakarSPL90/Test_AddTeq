import React from 'react';
import { Grid } from '@mui/material';
import MobileCard from './MobileCard';

const MobileGrid = ({ products, compareItems, toggleCompare }) => (
  <Grid container spacing={3}>
    {products.map((product) => (
      <Grid item xs={12} sm={6} md={4} key={product.id}>
        <MobileCard
          product={product}
          isCompared={!!compareItems.find((p) => p.id === product.id)}
          toggleCompare={toggleCompare}
        />
      </Grid>
    ))}
  </Grid>
);

export default MobileGrid;