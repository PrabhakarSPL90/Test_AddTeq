import React from 'react';
import { Box, Typography, Grid, Card, CardContent, Button } from '@mui/material';

const ComparisonSection = ({ compareItems, toggleCompare, setCompareItems }) => {
  const diffFeatures = {};
  compareItems.forEach((product) => {
    product.features.forEach((feature) => {
      diffFeatures[feature] = (diffFeatures[feature] || 0) + 1;
    });
  });

  if (compareItems.length < 2) return null;

  return (
    <Box sx={{ mt: 5 }}>
      <Typography variant="h5" gutterBottom>
        Comparison Bucket
      </Typography>
      <Grid container spacing={2}>
        {compareItems.map((product) => (
          <Grid item xs={12} sm={6} md={4} key={product.id}>
            <Card variant="outlined" sx={{ borderColor: 'primary.main' }}>
              <CardContent>
                <Typography variant="h6">{product.name}</Typography>
                <Typography variant="body2">{product.brand}</Typography>
                <img
                  src={product.image}
                  alt={product.name}
                  style={{ width: '100%', height: 100, objectFit: 'contain', margin: '1rem 0' }}
                />
                <Typography color="primary" fontWeight="bold">{product.price}</Typography>
                <ul>
                  {product.features.map((f, i) => (
                    <li
                      key={i}
                      style={{
                        backgroundColor: diffFeatures[f] === 1 ? '#ffe0e0' : 'transparent',
                        padding: '2px 4px',
                        borderRadius: '4px',
                      }}
                    >
                      {f}
                    </li>
                  ))}
                </ul>
                <Button
                  variant="outlined"
                  color="error"
                  onClick={() => toggleCompare(product)}
                  sx={{ mt: 2 }}
                >
                  Remove
                </Button>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
      <Button onClick={() => setCompareItems([])} variant="contained" color="error" sx={{ mt: 3 }}>
        Clear All
      </Button>
    </Box>
  );
};

export default ComparisonSection;