import React from 'react';
import { TextField } from '@mui/material';

const SearchBar = ({ search, setSearch, darkMode }) => (
  <TextField
    label="Search Products"
    variant="outlined"
    fullWidth
    value={search}
    onChange={(e) => setSearch(e.target.value)}
    sx={{
      mb: 3,
      input: { color: darkMode ? '#fff' : '#000' },
      label: { color: darkMode ? '#ccc' : '#000' },
      '& .MuiOutlinedInput-root': {
        '& fieldset': { borderColor: darkMode ? '#888' : '#ccc' },
        '&:hover fieldset': { borderColor: darkMode ? '#aaa' : '#000' },
        '&.Mui-focused fieldset': { borderColor: darkMode ? '#00bcd4' : '#1976d2' },
      },
    }}
  />
);

export default SearchBar;