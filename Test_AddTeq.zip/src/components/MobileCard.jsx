import React from 'react';
import { Card, CardMedia, CardContent, Typography, Button } from '@mui/material';

const MobileCard = ({ product, isCompared, toggleCompare }) => (
  <Card>
    <CardMedia
      component="img"
      sx={{ height: 140, objectFit: 'contain'}}
      image={product.image}
      alt={product.name}
    />
    <CardContent>
      <Typography variant="h6">{product.name}</Typography>
      <Typography variant="body2" color="text.secondary">{product.brand}</Typography>
      <Typography variant="subtitle1" fontWeight="bold">{product.price}</Typography>
      <ul>
        {product.features.map((f, i) => <li key={i}>{f}</li>)}
      </ul>
      <Button
        variant={isCompared ? 'outlined' : 'contained'}
        color={isCompared ? 'error' : 'primary'}
        onClick={() => toggleCompare(product)}
        sx={{ mt: 2 }}
      >
        {isCompared ? 'Remove' : 'Add to Compare'}
      </Button>
    </CardContent>
  </Card>
);

export default MobileCard;