import React, { useState, useEffect } from 'react';
import SearchBar from './components/SearchBar';
import MobileGrid from './components/MobileGrid';
import ComparisonSection from './components/ComparisonSection';

import {
  Typography,
  Switch,
  Container,
  AppBar,
  Toolbar,
  Box,
} from '@mui/material';

const sampleProducts = [
  {
    id: 1,
    name: 'Galaxy A30',
    brand: 'Samsung',
    image: 'https://i.gadgets360cdn.com/products/large/1551094093_635_samsung_galaxy_a_30.jpg?downsize=*:420&output-quality=80',
    price: '₹10,000',
    features: ['6.4\"', '64GB Storage', '4GB RAM', '4000mAh Battery Capacity'],
  },
  {
    id: 2,
    name: 'Galaxy S7 Edge',
    brand: 'Samsung',
    image: 'https://drop.ndtv.com/TECH/product_database/images/samsung_galaxy_s7edge_3311_480X960_326201633006PM.jpg?downsize=*:420&output-quality=80',
    price: '₹23,990',
    features: ['5.50\"', '32GB Storage', '4GB RAM', '3600mAh Battery Capacity']
  },
  {
    id: 3,
    name: 'Moto G86 Power',
    brand: 'Motorola',
    image: 'https://i.gadgets360cdn.com/large/moto_g86_power_5g_motorola_1753854035884.jpg?downsize=950:*',
    price: '₹28,489',
    features: ['6.67\"', '128GB Storage', '8GB RAM', '6720mAh Battery Capacity']
  },
  {
    id: 4,
    name: 'iPhone 14',
    brand: 'Apple',
    image: 'https://i.gadgets360cdn.com/products/large/iphone-14-db-400x800-1662580923.jpg?downsize=*:420&output-quality=80',
    price: '₹49,999',
    features: ['6.1\"', '128GB Storage', '8GB RAM', '']
  },
  {
    id: 5,
    name: 'V 30',
    brand: 'Vivo',
    image: 'https://rukminim2.flixcart.com/image/312/312/xif0q/mobile/o/g/3/v30-5g-v2318-vivo-original-imagyzhhxumayhzw.jpeg?q=70',
    price: '₹29,999',
    features: ['6.8\"', '128GB Storage', '8GB RAM', '5000mAh Battery Capacity']
  },
  {
    id: 6,
    name: 'realme 15 5G',
    brand: 'Realme',
    image: 'https://rukminim2.flixcart.com/image/312/312/xif0q/mobile/n/r/p/-original-imahe4exvhx3efv7.jpeg?q=70',
    price: '₹29,999',
    features: ['6.8\"', '128GB Storage', '8GB RAM', '5000mAh Battery Capacity']
  },
];

export default function App() {
  const [compareItems, setCompareItems] = useState(() => {
    const stored = localStorage.getItem('compareItems');
    return stored ? JSON.parse(stored) : [];
  });
  const [search, setSearch] = useState('');
  const [darkMode, setDarkMode] = useState(false);
  const diffFeatures = {};
  

  useEffect(() => {
    localStorage.setItem('compareItems', JSON.stringify(compareItems));
  }, [compareItems]);

  const toggleCompare = (product) => {
    setCompareItems((prev) => {
      const exists = prev.find((p) => p.id === product.id);
      if (exists) return prev.filter((p) => p.id !== product.id);
      if (prev.length < 3) return [...prev, product];
      return prev;
    });
  };

  const filteredProducts = sampleProducts.filter((product) =>
    product.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <Box sx={{ bgcolor: darkMode ? '#121212' : '#f5f5f5a9', minHeight: '100vh', color: darkMode ? '#fff' : '#000' }}>
      <AppBar position="static" color={darkMode ? 'default' : 'primary'}>
        <Toolbar>
          <Typography variant="h6" sx={{ flexGrow: 1}}>
            Choose Your Mobile
          </Typography>
          <Typography variant="body2">Dark Mode</Typography>
          <Switch checked={darkMode} onChange={() => setDarkMode(!darkMode)} />
        </Toolbar>
      </AppBar>

      <Container sx={{ py: 4 }}>
        <SearchBar search={search} setSearch={setSearch} darkMode={darkMode} />
        <Typography variant="h5" gutterBottom>  
          Listed Mobiles 
        </Typography>
        <MobileGrid
          products={filteredProducts}
          compareItems={compareItems}
          toggleCompare={toggleCompare}
          darkMode={darkMode}
        />
        <ComparisonSection
          compareItems={compareItems}
          toggleCompare={toggleCompare}
          setCompareItems={setCompareItems}
        />
      </Container>
    </Box>
  );
}
